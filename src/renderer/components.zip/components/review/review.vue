<template src='./review.html'>
<p>this is revierw page</p>
</template>

<style src='./review.css'>

</style>
