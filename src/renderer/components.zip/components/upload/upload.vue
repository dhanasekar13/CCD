<div>
<input type="file">
<input type="file">
<input type="file">
</div>
